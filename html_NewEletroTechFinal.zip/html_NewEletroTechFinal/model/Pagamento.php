<?php

class Pagamento {

private $id_pagamento;
private $value;
private $name_card;
private $id_agendamento;
private $id_usuario; 

function getID_pagamento(){
    return $this->id_pagamento;
} 

function getValue(){
    return $this->value;
} 

function getName_card(){
    return $this->name_card;
}
function getID_agendamento(){
    return $this->id_agendamento;
}

function getID_usuario(){
    return $this->id_usuario;
}


function setID_pagamento($id_pagamento){
    $this->id_pagamento=$id_pagamento;
}

function setValue($value){
    $this->value=$value;
}

function setName_card($name_card){
    $this->name_card=$name_card;
}

function setID_agendamento($data_agendamento){
    $this->data_agendamento=$data_agendamento;
}

function setID_Usuario($id_usuario){
    $this->id_usuario=$id_usuario;
}

}


?>