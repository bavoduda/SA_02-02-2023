<?php

class Agendamento {

private $id_agendamento;
private $id_usuario;
private $tipo_agendamento;
private $data_agendamento;
private $nome;
private $email;
private $cpf;
private $telefone;
private $sexo;
private $cep;
private $rua;
private $numero;
private $bairro;
private $cidade;
private $estado; 

function getID_agendamento(){
    return $this->id_agendamento;
} 

function getID_usuario(){
    return $this->id_usuario;
} 

function getTipo_agendamento(){
    return $this->tipo_agendamento;
}
function getData_agendamento(){
    return $this->data_agendamento;
}

function getNome(){
    return $this->nome;
}

function getEmail(){
    return $this->email;
}  

function getCPF(){
    return $this->cpf;
} 

function getTelefone(){
    return $this->telefone;
} 

function getSexo(){
    return $this->sexo;
}  

function getCep(){
    return $this->cep;
}

function getRua(){
    return $this->rua;
} 

function getNumero(){
    return $this->numero;
}

function getBairro(){
    return $this->bairro;
}

function getCidade(){
    return $this->cidade;
}

function getEstado(){
    return $this->estado;
}


function setID_agendamento($id_agendamento){
    $this->id_agendamento=$id_agendamento;
}

function setID_usuario($id_usuario){
    $this->id_usuario=$id_usuario;
}

function setTipo_agendamento($tipo_agendamento){
    $this->tipo_agendamento=$tipo_agendamento;
}

function setData_agendamento($data_agendamento){
    $this->data_agendamento=$data_agendamento;
}

function setNome($nome){
    $this->nome=$nome;
}

function setEmail($email){
    $this->email=$email;
}

function setCPF($cpf){
    $this->cpf=$cpf;
}

function setTelefone($telefone){
    $this->telefone=$telefone;
}

function setSexo($sexo){
    $this->sexo=$sexo;
}

function setCep($cep){
    $this->cep=$cep;
}

function setRua($rua){
    $this->rua=$rua;
}

function setNumero($numero){
    $this->numero=$numero;
}

function setBairro($bairro){
    $this->bairro=$bairro;
}

function setCidade($cidade){
    $this->cidade=$cidade;
}

function setEstado($estado){
    $this->estado=$estado;
}



}


?>