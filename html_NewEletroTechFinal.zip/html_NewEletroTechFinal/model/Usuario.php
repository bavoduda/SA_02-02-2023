<?php

class Usuario {

private $id;
private $nome;
private $email;
private $cpf;
private $telefone;
private $sexo;
private $data_nascimento;
private $senha; 

function getID(){
    return $this->id;
} 

function getNome(){
    return $this->nome;
} 

function getEmail(){
    return $this->email;
}  

function getCPF(){
    return $this->cpf;
} 

function getTelefone(){
    return $this->telefone;
} 

function getSexo(){
    return $this->sexo;
}  

function getData_nascimento(){
    return $this->data_nascimento;
}

function getSenha(){
    return $this->senha;
} 



function setID($id){
    $this->id=$id;
} 

function setNome($nome){
    $this->nome=$nome;
}

function setEmail($email){
    $this->email=$email;
}

function setCPF($cpf){
    $this->cpf=$cpf;
}

function setTelefone($telefone){
    $this->telefone=$telefone;
}

function setSexo($sexo){
    $this->sexo=$sexo;
}

function setData_nascimento($data_nascimento){
    $this->data_nascimento=$data_nascimento;
}

function setSenha($senha){
    $this->senha=$senha;
}



}


?>