<?php

class PagamentoDao{

    public function criar(Pagamento $pagamento){ 

        try { 
                
        $sql = "INSERT INTO pagamento(value, name_card, id_agendamento, id_usuario) VALUES (:value, :name_card, :id_agendamento, :id_usuario)";

        $stmt = Conexao::getConexao()->prepare($sql);

        $stmt->bindValue(":value", $pagamento->getValue(), PDO::PARAM_STR);
        $stmt->bindValue(":name_card", $pagamento->getNome(), PDO::PARAM_STR);
        $stmt->bindValue(":id_agendamento", $pagamento->getID_agendamento(), PDO::PARAM_STR);
        $stmt->bindValue(":id_user", $pagamento->getID_usuario(), PDO::PARAM_STR);

        return $stmt->execute();
        
        } catch (\PDOException $e) {
        
            echo "Erro ao cadastrar o pagamento <br> " . $e->getMessage() . '<br>';
        }


    } 

    public function editar(){
        try {
            $sql = "SELECT * FROM agendamento WHERE id_agendamento=:id";
            $stmt= Conexao::getConexao()->prepare($sql);
            $stmt->bindValue(":id", $_POST['id_agendamento'], PDO::PARAM_INT);
            $stmt->execute();
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC); 
            $list = array();
    
           foreach ($lista as $linha ) {
            $list[]=$this->listaAgendamentos($linha);
           } 
           return $list;
        } catch (\PDOException $e) {
          echo "Ocorreu um erro ao tentar listar os agendamentos cadastrados!" . $e->getMessage();
    }
    } 

}

?>