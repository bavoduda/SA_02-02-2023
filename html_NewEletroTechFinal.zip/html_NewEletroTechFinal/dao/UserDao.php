<?php

class UserDao{

    public function criar(Usuario $usuario){ 

        try { 
                 
        $sql = "INSERT INTO usuario(nome, email, cpf, telefone, sexo, data_nascimento, senha) VALUES (:nome, :email, :cpf, :telefone, :sexo, :data_nascimento, :senha)";

        $stmt = Conexao::getConexao()->prepare($sql);
        $stmt->bindValue(":nome", $usuario->getNome(), PDO::PARAM_STR);
        $stmt->bindValue(":email", $usuario->getEmail(), PDO::PARAM_STR);
        $stmt->bindValue(":cpf", $usuario->getCPF(), PDO::PARAM_STR);
        $stmt->bindValue(":telefone", $usuario->getTelefone(), PDO::PARAM_STR);
        $stmt->bindValue(":sexo", $usuario->getSexo(), PDO::PARAM_STR);
        $stmt->bindValue(":data_nascimento", $usuario->getData_nascimento(), PDO::PARAM_STR);
        $stmt->bindValue(":senha", $usuario->getSenha(), PDO::PARAM_STR);

        return $stmt->execute();
           
        } catch (\PDOException $e) {
           
            echo "Erro ao cadastrar os dados do usuário <br> " . $e->getMessage() . '<br>';
        }
   

    } 

    public function listar(){
        try {
            $sql = "SELECT * FROM usuario ORDER BY nome ASC";
            $stmt= Conexao::getConexao()->query($sql);
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC); 
            $list = array();

           foreach ($lista as $linha ) {
            $list[]=$this->listaUsuarios($linha);
           } 
           return $list;

        } catch (\PDOException $e) {
          echo "Ocorreu um erro ao tentar listar os usuarios cadastrados!" . $e->getMessage();
    }
}   

public function alterar(Usuario $usuario){ 

    try { 
             
    $sql = "UPDATE usuario SET nome = :nome, email = :email, cpf = :cpf, telefone = :telefone , sexo = :sexo , senha = :senha WHERE id_usuario = :id";

    $stmt = Conexao::getConexao()->prepare($sql);
    $stmt->bindValue(":id", $usuario->getID(), PDO::PARAM_INT);
    $stmt->bindValue(":nome", $usuario->getNome(), PDO::PARAM_STR);
    $stmt->bindValue(":email", $usuario->getEmail(), PDO::PARAM_STR);
    $stmt->bindValue(":cpf", $usuario->getCPF(), PDO::PARAM_STR);
    $stmt->bindValue(":telefone", $usuario->getTelefone(), PDO::PARAM_STR);
    $stmt->bindValue(":sexo", $usuario->getSexo(), PDO::PARAM_STR);
    $stmt->bindValue(":senha", $usuario->getSenha(), PDO::PARAM_STR);

    return $stmt->execute();
       
    } catch (\PDOException $e) {
       
        echo "Erro ao Atualizar  os dados do usuário " . $e->getMessage();
    }


} 

public function editar(){
    try {
        $sql = "SELECT * FROM usuario WHERE id_usuario=:id";
        $stmt= Conexao::getConexao()->prepare($sql);
        $stmt->bindValue(":id", $_POST['id_edit'], PDO::PARAM_INT);
        $stmt->execute();
        $lista = $stmt->fetchAll(PDO::FETCH_ASSOC); 
        $list = array();

       foreach ($lista as $linha ) {
        $list[]=$this->listaUsuarios($linha);
       } 
       return $list;
    } catch (\PDOException $e) {
      echo "Ocorreu um erro ao tentar listar os usuarios cadastrados!" . $e->getMessage();
}
} 

public function user() {
    try {
        $sql = "SELECT * FROM usuario WHERE id_usuario = :id";
        $stmt = Conexao::getConexao()->prepare($sql);
        $stmt->bindValue(":id", $_SESSION['user_session'] , PDO::PARAM_INT);
        $stmt->execute();
        $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $list = array();

        foreach ($lista as $linha) {
            $list[] = $this->listaUsuarios($linha);
        }

        return $list;

    } catch (PDOException $e) {
        echo "Ocorreu um erro ao tentar buscar Usuário." . $e->getMessage();
    }

}


public function listausuarios($linhas){
    $usuario = new Usuario();
    $usuario->setID($linhas['id_usuario']);
    $usuario->setNome($linhas['nome']);
    $usuario->setEmail($linhas['email']);
    $usuario->setCPF($linhas['cpf']);
    $usuario->setTelefone($linhas['telefone']);
    $usuario->setSexo($linhas['sexo']);

    return $usuario;
   

}  






public function excluir(Usuario $usuario){
    try {
       
    $sql = "DELETE FROM usuario WHERE id_usuario = :id";
    $stmt = Conexao::getConexao()->prepare($sql);
    $stmt->bindValue(":id", $usuario->getID(), PDO::PARAM_INT);

    return $stmt->execute();

    } catch (\PDOException $e) {
        echo "Erro ao tentar excluir Usuário!" .$e->getMessage();
    }
}

    public function login(Usuario $usuario) {
        try {
            
            $sql = "SELECT * FROM usuario WHERE email = :email";
            $stmt = Conexao::getConexao()->prepare($sql);
            $stmt->bindValue(":email", $usuario->getEmail(), PDO::PARAM_STR);
            $stmt->execute();

            $user_linha = $stmt->fetch(PDO::FETCH_ASSOC);

            if($stmt->rowCount() == 1) {

                if(password_verify($usuario->getSenha(), $user_linha['senha'])) {

                   $_SESSION['user_session'] = $user_linha['id_usuario'];
                   $_SESSION['nome_session'] = $user_linha['nome'];
                   session_start();
                   return true;

                } else {
                    echo "Senha Errada";
                    return false;
                }
            }


        } catch (PDOException $e) {
            
            echo "Erro ao tentar realizar o login do usuário!" . $e->getMessage();

        }
    }

    public function checkLogin() {
        if (isset($_SESSION['user_session'])) {
            return true;
        } else {
            return false;
        }
    }

    public function logout() {
        session_start();
        session_destroy();
        unset($_SESSION['user_session']);
        unset($_SESSION['nome_session']);
        return true;

    }

}
?>