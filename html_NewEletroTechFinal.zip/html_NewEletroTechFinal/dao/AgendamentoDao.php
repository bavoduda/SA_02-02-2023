<?php

class AgendamentoDao{

    public function criar(Agendamento $agendamento){ 

        try { 
                
        $sql = "INSERT INTO agendamento(id_usuario, tipo_agendamento, data_agendamento, nome, email, cpf, telefone, sexo, cep, rua, numero, bairro, cidade, estado) VALUES (:id_user, :tipo_agendamento, :data_agendamento, :nome, :mail, :cpf, :telefone, :sexo, :cep, :rua, :numero, :bairro, :cidade1, :uf)";

        $stmt = Conexao::getConexao()->prepare($sql);

        $stmt->bindValue(":id_user", $agendamento->getID_usuario(), PDO::PARAM_STR);
        $stmt->bindValue(":tipo_agendamento", $agendamento->getTipo_agendamento(), PDO::PARAM_STR);
        $stmt->bindValue(":data_agendamento", $agendamento->getData_agendamento(), PDO::PARAM_STR);
        $stmt->bindValue(":nome", $agendamento->getNome(), PDO::PARAM_STR);
        $stmt->bindValue(":mail", $agendamento->getEmail(), PDO::PARAM_STR);
        $stmt->bindValue(":cpf", $agendamento->getCPF(), PDO::PARAM_STR);
        $stmt->bindValue(":telefone", $agendamento->getTelefone(), PDO::PARAM_STR);
        $stmt->bindValue(":sexo", $agendamento->getSexo(), PDO::PARAM_STR);
        $stmt->bindValue(":cep", $agendamento->getCep(), PDO::PARAM_STR);
        $stmt->bindValue(":rua", $agendamento->getRua(), PDO::PARAM_STR);
        $stmt->bindValue(":numero", $agendamento->getNumero(), PDO::PARAM_STR);
        $stmt->bindValue(":bairro", $agendamento->getBairro(), PDO::PARAM_STR);
        $stmt->bindValue(":cidade1", $agendamento->getCidade(), PDO::PARAM_STR);
        $stmt->bindValue(":uf", $agendamento->getEstado(), PDO::PARAM_STR);

        return $stmt->execute();
        
        } catch (\PDOException $e) {
        
            echo "Erro ao cadastrar o agendamento <br> " . $e->getMessage() . '<br>';
        }

    }

    public function editar(){
        try {
            $sql = "SELECT * FROM agendamento WHERE id_agendamento=:id";
            $stmt= Conexao::getConexao()->prepare($sql);
            $stmt->bindValue(":id", $_POST['id_agendamento'], PDO::PARAM_INT);
            $stmt->execute();
            $lista = $stmt->fetchAll(PDO::FETCH_ASSOC); 
            $list = array();
    
           foreach ($lista as $linha ) {
            $list[]=$this->listaAgendamentos($linha);
           } 
           return $list;
        } catch (\PDOException $e) {
          echo "Ocorreu um erro ao tentar listar os agendamentos cadastrados!" . $e->getMessage();
    }
    } 

}

?>