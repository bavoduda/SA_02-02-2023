-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2023 at 05:49 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mvc_php_dao`
--

-- --------------------------------------------------------

--
-- Table structure for table `agendamento`
--

CREATE TABLE `agendamento` (
  `id_agendamento` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `tipo_agendamento` varchar(90) NOT NULL,
  `data_agendamento` date NOT NULL,
  `nome` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `telefone` varchar(14) NOT NULL,
  `sexo` varchar(45) NOT NULL,
  `cep` varchar(45) NOT NULL,
  `rua` varchar(90) NOT NULL,
  `numero` int(11) NOT NULL,
  `bairro` varchar(90) NOT NULL,
  `cidade` varchar(90) NOT NULL,
  `estado` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `agendamento`
--

INSERT INTO `agendamento` (`id_agendamento`, `id_usuario`, `tipo_agendamento`, `data_agendamento`, `nome`, `email`, `cpf`, `telefone`, `sexo`, `cep`, `rua`, `numero`, `bairro`, `cidade`, `estado`) VALUES
(2, 4, 'Instalação de tomadas e/ou interruptores', '2023-01-30', 'Nikolas Gabriel Oliveira', 'nikolas@eletrotech.com', '234.653.721-62', '(31)99652-3070', 'M', '30285299', 'Beco Maximiano', 67, 'Alto Vera Cruz', 'Belo Horizonte', 'MG'),
(3, 4, 'Reparo em rede residencial', '2023-02-22', 'Nikolas Gabriel Oliveira', 'nikolas@eletrotech.com', '234.653.721-62', '(31)99652-3070', 'M', '30285300', 'Rua Tebas', 25, 'Vera Cruz', 'Belo Horizonte', 'MG'),
(4, 4, 'Instalação padrão energia', '2024-02-01', 'Nikolas Gabriel Oliveira', 'nikolas@eletrotech.com', '234.653.721-62', '(31)99652-3070', 'M', '30280300', 'Rua Pirite', 26, 'Esplanada', 'Belo Horizonte', 'MG'),
(5, 4, 'Reparo em rede residencial', '2023-10-25', 'Nikolas Gabriel Oliveira', 'nikolas@eletrotech.com', '234.653.721-62', '(31)99652-3070', 'M', '30285300', 'Rua Tebas', 71, 'Vera Cruz', 'Belo Horizonte', 'MG');

-- --------------------------------------------------------

--
-- Table structure for table `funcionario`
--

CREATE TABLE `funcionario` (
  `id_funcionario` int(11) NOT NULL,
  `user` varchar(45) NOT NULL,
  `senha` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `funcionario`
--

INSERT INTO `funcionario` (`id_funcionario`, `user`, `senha`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `pagamento`
--

CREATE TABLE `pagamento` (
  `id_pagamento` int(11) NOT NULL,
  `value` float DEFAULT NULL,
  `name_card` varchar(45) DEFAULT NULL,
  `id_agendamento` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `produto`
--

CREATE TABLE `produto` (
  `id_produto` int(11) NOT NULL,
  `nome` varchar(180) NOT NULL,
  `preco` float NOT NULL,
  `marca` varchar(50) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `imagem` varchar(180) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `produto`
--

INSERT INTO `produto` (`id_produto`, `nome`, `preco`, `marca`, `quantidade`, `imagem`) VALUES
(1, 'Teclado', 150, 'Corsair', 9, 'Teclado_23260341.png'),
(12, 'Impressora multifuncional HP DeskJet Ink Advantage', 329.99, 'HP', 4, 'Impressora multifuncional HP DeskJet Ink Advantage_1247750457.jpg'),
(13, 'Impressora multifuncional HP DeskJet Ink Advantage', 329.99, 'HP', 4, 'Impressora multifuncional HP DeskJet Ink Advantage_582529244.jpg'),
(14, 'Impressora multifuncional HP DeskJet Ink Advantage', 329.99, 'HP', 4, 'Impressora multifuncional HP DeskJet Ink Advantage_1524442717.jpg'),
(15, 'Impressora multifuncional HP DeskJet Ink Advantage', 329.99, 'HP', 4, 'Impressora multifuncional HP DeskJet Ink Advantage_1995622815.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `cpf` varchar(15) NOT NULL,
  `telefone` varchar(15) NOT NULL,
  `sexo` char(1) NOT NULL,
  `data_nascimento` date NOT NULL,
  `senha` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nome`, `email`, `cpf`, `telefone`, `sexo`, `data_nascimento`, `senha`) VALUES
(1, 'Admin', 'admin@email.com', '111.111.111-11', '999999999', 'O', '2000-01-01', '$2y$10$4qqZVXwHfCzHCUJrOpjczOnHjTPZaBx5j3WuswTHmX32wMNPvKAue'),
(4, 'Nikolas Gabriel Oliveira', 'nikolas@eletrotech.com.br', '234.653.721-62', '(31)99652-3070', 'M', '2001-11-03', '$2y$10$A7ix27r6.iokeZAu7oMeDeTCnucRj1X4tvNACBiRMpz95YR/chjMS'),
(6, 'Thais Barbosa', 'thais@eletrotech.com', '467.392.011-40', '(31)98763-9201', 'F', '2004-04-24', '$2y$10$h7gLJJVNiHNK6VP7c0CSEeZBHXYjsrrj82Os3RLmKxcJktQficHmC');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agendamento`
--
ALTER TABLE `agendamento`
  ADD PRIMARY KEY (`id_agendamento`,`id_usuario`),
  ADD UNIQUE KEY `id_agendamento_UNIQUE` (`id_agendamento`),
  ADD KEY `fk_agendamento_usuario_idx` (`id_usuario`);

--
-- Indexes for table `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`id_funcionario`),
  ADD UNIQUE KEY `id_funcionario_UNIQUE` (`id_funcionario`);

--
-- Indexes for table `pagamento`
--
ALTER TABLE `pagamento`
  ADD PRIMARY KEY (`id_pagamento`,`id_agendamento`,`id_usuario`),
  ADD UNIQUE KEY `id_pagamento_UNIQUE` (`id_pagamento`),
  ADD KEY `fk_pagamento_agendamento1_idx` (`id_agendamento`,`id_usuario`);

--
-- Indexes for table `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`id_produto`),
  ADD UNIQUE KEY `id_produto_UNIQUE` (`id_produto`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `id_usuario_UNIQUE` (`id_usuario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agendamento`
--
ALTER TABLE `agendamento`
  MODIFY `id_agendamento` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `funcionario`
--
ALTER TABLE `funcionario`
  MODIFY `id_funcionario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pagamento`
--
ALTER TABLE `pagamento`
  MODIFY `id_pagamento` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `produto`
--
ALTER TABLE `produto`
  MODIFY `id_produto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `agendamento`
--
ALTER TABLE `agendamento`
  ADD CONSTRAINT `fk_agendamento_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `pagamento`
--
ALTER TABLE `pagamento`
  ADD CONSTRAINT `fk_pagamento_agendamento1` FOREIGN KEY (`id_agendamento`,`id_usuario`) REFERENCES `agendamento` (`id_agendamento`, `id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
