<?php

session_start();

require_once('../../config/Conexao.php');
require_once('../../dao/ProdutoDao.php');
require_once('../../dao/UserDao.php');
require_once('../../model/Produto.php');

//instancia as classes
$produto = new Produto();
$produtodao = new ProdutoDao();

$login = new UserDao();

$id = $_SESSION['user_session'];

if(!$login->checkLogin() || $id != 1) {
    header("Location: ../login");
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Atualizar dados do Produto </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
</head>
<body> 

    <h2> Editar Dados do Produto </h2>
    <fieldset style="width:600px; border: 4px solid #098;">
        <legend style="font-size:14pt; font-weight:bolder;"> Atualize os dados: </legend>
        <form action="../../controller/ProdutoController.php" method="post" name="cad">
            <?php foreach($produtodao->editarproduto() as $produto):?>
            <label> Nome: </label>
            <input type="hidden" name="id_alter" id="id_alter" value="<?=$produto->getID()?>" required/>
            <input type="text" name="nome" id="nome" value="<?=$produto->getNome()?>" required/>
            <br/> <br/>
            <label> Preço: </label>
            <input type="text" name="preco" id="mail" value="<?=$produto->getPreco()?>" required/>
            <br/> <br/> 
            <label> Marca: </label>
            <input type="text" name="marca" id="cpf" value="<?=$produto->getMarca()?>" required/>
            <br/> <br/>
            <label> Quantidade: </label>
            <input type="number" name="qtd" id="telefone" value="<?=$produto->getQuantidade()?>" required/>
            <br/> <br/>  
            <input type="submit" name="alterar" id="alterar" value="ALTERAR"/>
            <button> <a href="../../index.php" style="text-decoration: none;">VOLTAR</a></button>

            <?php endforeach?>
        </form>
       </fieldset> 
    
</body>
</html>
