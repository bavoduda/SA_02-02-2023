

function gerarCidades() {
  var estado = document.getElementById("estado").value;

  var cidade = document.getElementById("cidade");

  var option = "";

  if (estado == "") {
    limpaCombo();
  }
  
  if (estado == "SP") {
    limpaCombo();

    option = document.createElement("option");
    option.value = "1";
    option.text = "Limeira"; 
    cidade.add(option);  

    option = document.createElement("option");
    option.value = "2";
    option.text = "Campinas"; 
    cidade.add(option);  

    option = document.createElement("option");
    option.value = "3";
    option.text = "Valinhos"; 
    cidade.add(option);                  
  }

  if (estado == "MG") {
    limpaCombo();

    option = document.createElement("option");
    option.value = "1";
    option.text = "Belo Horizonte"; 
    cidade.add(option);  

    option = document.createElement("option");
    option.value = "2";
    option.text = "Contagem"; 
    cidade.add(option);  

    option = document.createElement("option");
    option.value = "3";
    option.text = "Ibirité"; 
    cidade.add(option);                  
  }    


  if (estado == "RJ") {
    limpaCombo();

    option = document.createElement("option");
    option.value = "1";
    option.text = "Rio de Janeiro"; 
    cidade.add(option);  

    option = document.createElement("option");
    option.value = "2";
    option.text = "Rezende"; 
    cidade.add(option);  

    option = document.createElement("option");
    option.value = "3";
    option.text = "Angra dos Reis"; 
    cidade.add(option);                  
  }        

}

function limpaCombo() {
  var comboCidades = document.getElementById("cidade");
  
  while (comboCidades.length) {
    comboCidades.remove(0);
  }
}

