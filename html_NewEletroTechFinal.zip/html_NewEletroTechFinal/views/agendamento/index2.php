<?php

require_once('../../config/Conexao.php');
require_once('../../dao/UserDao.php');
require_once('../../dao/AgendamentoDao.php');
require_once('../../model/Usuario.php');
require_once('../../model/Agendamento.php');

//instancia as classes
$agendamento = new Agendamento();
$agendamentodao = new AgendamentoDao();
$usuario = new Usuario();
$userdao = new UserDao();


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Contratar Serviço</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
            background-image: linear-gradient(to right, rgb(20,147,220), rgb(17, 54, 71));
        }

        .box{
            color: white;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: rgba(0, 0, 0, 0.6);
            padding: 15px;
            border-radius: 15px;
        }
        fieldset{
            border: 3px solid dodgerblue;
        }
        legend{
            border: 1px solid dodgerblue;
            padding: 10px;
            text-align: center;
            background-color: dodgerblue;
            border-radius: 8px;
        }
        .inputBox{
            position: relative;
        }
        .inputUser{
            background: none;
            border: none;
            border-bottom: 1px solid white;
            outline: none;
            color: white;
            font-size: 15px;
            width: 100%;
            letter-spacing: 2px;
        }
        .labelinput{
            position: absolute;
            top: 0px;
            left: 0px;
            pointer-events: none;
            transition: .5s;
        }
        .labelinputcpf{
            position: absolute;
            top: 0px;
            left: 0px;
            pointer-events: none;
            transition: .5s;
        }
        .inputUser:focus ~ .labelinput, .inputUser:valid ~ .labelinput{
            top: -20px;
            font-size: 12px;
            color: dodgerblue;
        } 
        
        #data_agendamento{
            border: none;
            padding: 8px;
            border-radius: 10px;
            outline: none;
            font-size: 15px;
        }
        #cadastrar_agendamento, button{
            background-image: linear-gradient(to right, rgb(0, 92, 197), rgb(90, 20, 220));
            width: 100%;
            border: none;
            padding: 15px;
            color: white;
            font-size: 15px;
            cursor: pointer;
            border-radius: 10px;
        }

        #cadastrar:hover{
            background-image: linear-gradient(to right, rgb(0, 80, 172), rgb(80, 19, 195));
        }
    </style>
   
</head>

<script>
    
    function limpa_formulário_cep() {
            //Limpa valores do formulário de cep.
            document.getElementById('rua').value=("");
            document.getElementById('bairro').value=("");
            document.getElementById('cidade1').value=("");
            document.getElementById('uf').value=("");
    }

    function meu_callback(conteudo) {
        if (!("erro" in conteudo)) {
            //Atualiza os campos com os valores.
            document.getElementById('rua').value=(conteudo.logradouro);
            document.getElementById('bairro').value=(conteudo.bairro);
            document.getElementById('cidade1').value=(conteudo.localidade);
            document.getElementById('uf').value=(conteudo.uf);
        } //end if.
        else {
            //CEP não Encontrado.
            limpa_formulário_cep();
            alert("CEP não encontrado.");
        }
    }
        
    function pesquisacep(valor) {

        //Nova variável "cep" somente com dígitos.
        var cep = valor.replace(/\D/g, '');

        //Verifica se campo cep possui valor informado.
        if (cep != "") {

            //Expressão regular para validar o CEP.
            var validacep = /^[0-9]{8}$/;

            //Valida o formato do CEP.
            if(validacep.test(cep)) {

                //Preenche os campos com "..." enquanto consulta webservice.
                document.getElementById('rua').value="...";
                document.getElementById('bairro').value="...";
                document.getElementById('cidade1').value="...";
                document.getElementById('uf').value="...";

                //Cria um elemento javascript.
                var script = document.createElement('script');

                //Sincroniza com o callback.
                script.src = 'https://viacep.com.br/ws/'+ cep + '/json/?callback=meu_callback';

                //Insere script no documento e carrega o conteúdo.
                document.body.appendChild(script);

            } //end if.
            else {
                //cep é inválido.
                limpa_formulário_cep();
                alert("Formato de CEP inválido.");
            }
        } //end if.
        else {
            //cep sem valor, limpa formulário.
            limpa_formulário_cep();
        }
    };


    </script>

<body> 

    <div class="box">
    <fieldset style="width:600px; border: 4px solid #098;">
        <legend style="font-size:14pt; font-weight:bolder;"> Agendamento: </legend>
        <form action="../../controller/AgendamentoController.php" method="post" name="agendamento">
            <?php foreach($userdao->editar() as $usuario):?>

            <input type="hidden" name="id_user" id="id_user" value="<?=$usuario->getID()?>" required/>
            <input type="hidden" name="nome" id="nome" value="<?=$usuario->getNome()?>" required/>
            <input type="hidden" name="mail" id="mail" value="<?=$usuario->getEmail()?>" required/>
            <input type="hidden" name="cpf" id="cpf" value="<?=$usuario->getCPF()?>" required/>
            <input type="hidden" name="telefone" id="telefone" value="<?=$usuario->getTelefone()?>" required/>
            <select id="sexo" name="sexo" hidden>
                <option value="" selected>--Selecione--</option>
                <option value="M"<?= $usuario->getSexo() == "M" ? "selected" : ""?>> Masculino </option>
                <option value="F" <?= $usuario->getSexo() == "F" ? "selected" : ""?>> Feminino </option>
                <option value="O" <?= $usuario->getSexo() == "O" ? "selected" : ""?>> Outro </option>
            </select>
            Tipo de serviço:<br>
            <select for="tipo_agendamento" id="tipo_agendamento" name="tipo_agendamento">
                    <option></option>
                    <option value="Instalação padrão energia">Instalação de padrão de energia elétrica</option>
                    <option value="Reparo em rede residencial">Reparo em rede elétrica residencial</option>
                    <option value="Instalação de tomadas e/ou interruptores">Instalação de tomadas e/ou interruptores</option>
                  </select>
                  <br><br>
                    <label for="data_agendamento"><b>Data de Agendamento:</b></label>
                    <input type="date" name="data_agendamento" id="data_agendamento" required>
            <br/><br/>
                <div class="inputBox">
                    <input name="cep" type="text" id="cep" value="" size="10" maxlength="9" class= "inputUser" onblur="pesquisacep(this.value);" required>
                    <label for = "cep" class="labelinput">Cep:</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input name="rua" type="text" id="rua" size="60" class= "inputUser" required>
                    <label for = "rua" class="labelinput">Rua:</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="text" name="numero" id="numero" class="inputUser" required>
                    <label for="numero" class="labelinput">Número:</label>
                    </div>
                    <br><br>
                <div class="inputBox">
                    <input name="bairro" type="text" id="bairro" size="40" class= "inputUser" required>
                    <label for = "bairro" class="labelinput">Bairro:</label>
                </div> 
                <br><br>
                <div class="inputBox">
                    <input name="cidade1" type="text" id="cidade1" size="40" class= "inputUser" required>
                    <label for = "cidade1" class="labelinput" >Cidade:</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input name="uf" type="text" id="uf" size="2" class= "inputUser" required>
                    <label for = "uf" class="labelinput">Estado:</label>
                </div>
                <br><br>
            </form>
            <input type="submit" name="cadastrar_agendamento" id="cadastrar_agendamento" value="FINALIZAR PEDIDO"/>
            <br><br>
            <button> <a href = "../../index.php" style="text-decoration: none;">VOLTAR</a></button>
            <?php endforeach?>
            </fieldset> 
            </form>
            </div>
       
    
</body>
</html>