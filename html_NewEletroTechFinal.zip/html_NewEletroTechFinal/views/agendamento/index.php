<?php

require_once('../../config/Conexao.php');
require_once('../../dao/UserDao.php');
require_once('../../dao/AgendamentoDao.php');
require_once('../../model/Usuario.php');
require_once('../../model/Agendamento.php');
require_once('../../dao/PagamentoDao.php');

//instancia as classes
$agendamento = new Agendamento();
$agendamentodao = new AgendamentoDao();
$usuario = new Usuario();
$userdao = new UserDao();
$pagamentodao = new PagamentoDao();


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Contratar Serviço</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  
   
</head>

<script>
    
    function limpa_formulário_cep() {
            //Limpa valores do formulário de cep.
            document.getElementById('rua').value=("");
            document.getElementById('bairro').value=("");
            document.getElementById('cidade1').value=("");
            document.getElementById('uf').value=("");
    }

    function meu_callback(conteudo) {
        if (!("erro" in conteudo)) {
            //Atualiza os campos com os valores.
            document.getElementById('rua').value=(conteudo.logradouro);
            document.getElementById('bairro').value=(conteudo.bairro);
            document.getElementById('cidade1').value=(conteudo.localidade);
            document.getElementById('uf').value=(conteudo.uf);
        } //end if.
        else {
            //CEP não Encontrado.
            limpa_formulário_cep();
            alert("CEP não encontrado.");
        }
    }
        
    function pesquisacep(valor) {

        //Nova variável "cep" somente com dígitos.
        var cep = valor.replace(/\D/g, '');

        //Verifica se campo cep possui valor informado.
        if (cep != "") {

            //Expressão regular para validar o CEP.
            var validacep = /^[0-9]{8}$/;

            //Valida o formato do CEP.
            if(validacep.test(cep)) {

                //Preenche os campos com "..." enquanto consulta webservice.
                document.getElementById('rua').value="...";
                document.getElementById('bairro').value="...";
                document.getElementById('cidade1').value="...";
                document.getElementById('uf').value="...";

                //Cria um elemento javascript.
                var script = document.createElement('script');

                //Sincroniza com o callback.
                script.src = 'https://viacep.com.br/ws/'+ cep + '/json/?callback=meu_callback';

                //Insere script no documento e carrega o conteúdo.
                document.body.appendChild(script);

            } //end if.
            else {
                //cep é inválido.
                limpa_formulário_cep();
                alert("Formato de CEP inválido.");
            }
        } //end if.
        else {
            //cep sem valor, limpa formulário.
            limpa_formulário_cep();
        }
    };

    </script>

<body> 
    <style>
   
        body{
         background-color: rgb(200, 221, 248);
        } 
        nav{
         font-weight: bolder;
        
        } 
     
        .hide{
         display: none;
        }
     
        footer{
         font-weight: bolder;
        }
       </style> 
     
         <nav  class="navbar  bg-primary navbar-expand-lg  bg-body-tertiary fixed-top"  style="z-index: 999; " data-bs-theme="dark" >
             <div class="container-fluid">
              
               <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" >
                 <span class="navbar-toggler-icon"></span>
               </button>
               <div class="collapse navbar-collapse" id="navbarSupportedContent">
                 <ul class="navbar-nav me-auto mb-2 mb-lg-0" >
                   <li class="nav-item">
                     <a class="nav-link active" aria-current="page" href="../../main.php">Home</a>
                   </li>
                   <li class="nav-item">
                     <a class="nav-link" href="../sobre/sobre.html">Sobre</a>
                   </li>
                   <li class="nav-item">
                     <a class="nav-link" href="../contato/contato.html">Contato</a>
                   </li>
                   
                   
                 </ul>
                 <div class="position-absolute top-50 start-50 translate-middle">
                 <form class="d-flex " role="search">
                   <div class="input-group mb-3">
                     <input type="search" id="busca" class="form-control" placeholder="Pesquisar" list="menu" autocomplete="off" onkeyup="Pesquisar()">
                     <datalist id="menu">
                       <option>Contato</option>
                       <option>Cadastro</option>
                       <option>Sobre</option>
                       <option> Siga nossas redes</option>
                       <option>  Login </option>
                     </datalist>
                     <div class="input-group-append">
                       <button class="btn btn-success" type="submit">Search</button>
                     </div>
                     </div>
                     
                 </form>
                 </div>
                 <div class="position-absolute top-50 end-0 translate-middle-y ">
                  <a href="index.php"  ><img src="../../img/perfil.png" alt="some text" width=60 height=40></a>
                     </div>
                     
                   </div>
                 </div>
               </div>
             </div>
           </nav>
           <br><br><br>
          <main>
             <img class="rounded mx-auto d-block"src="../../img/Logo-azul.png" alt="Logo" width=550 height=150>
             
           <br><br><br>

    <div class="container-lg">
   
        <legend style="font-size:14pt; font-weight:bolder;" align="center"> Agendamento: </legend>
        <form action="../../controller/AgendamentoController.php" method="post" name="agendamento">
            <?php foreach($userdao->editar() as $usuario):?>

            <input type="hidden" name="id_user" id="id_user" value="<?=$usuario->getID()?>" class="form-control" aria-label="First name" required />
            <input type="hidden" name="nome" id="nome" value="<?=$usuario->getNome()?>" class="form-control" aria-label="First name" required/>
            <input type="hidden" name="mail" id="mail" value="<?=$usuario->getEmail()?>" class="form-control" aria-label="First name" required/>
            <input type="hidden" name="cpf" id="cpf" value="<?=$usuario->getCPF()?>" class="form-control" aria-label="First name" required/>
            <input type="hidden" name="telefone" id="telefone" value="<?=$usuario->getTelefone()?>"class="form-control" aria-label="First name" required/>
            <select id="sexo" name="sexo" class="form-select" hidden>
                <option value="" selected>--Selecione--</option>
                <option value="M"<?= $usuario->getSexo() == "M" ? "selected" : ""?>> Masculino </option>
                <option value="F" <?= $usuario->getSexo() == "F" ? "selected" : ""?>> Feminino </option>
                <option value="O" <?= $usuario->getSexo() == "O" ? "selected" : ""?>> Outro </option>
            </select>
            <div class="input-group mb-3">
           <label class="input-group-text">Tipo de serviço:</label>
            <select for="tipo_agendamento" id="tipo_agendamento" name="tipo_agendamento" class="form-select">
                    <option></option>
                    <option value="Instalação padrão energia">Instalação de padrão de energia elétrica</option>
                    <option value="Reparo em rede residencial">Reparo em rede elétrica residencial</option>
                    <option value="Instalação de tomadas e/ou interruptores">Instalação de tomadas e/ou interruptores</option>
                  </select>
                </div>
                <div class="mb-3">
                    <label for="data_agendamento" class="form-label"><b>Data de Agendamento:</b></label>
                    <input type="date" name="data_agendamento" id="data_agendamento" class="form-control" aria-label="First name"  required>
           </div>
           <div class="mb-3">
                   <label for = "cep" class="form-label">Cep:</label>
                    <input name="cep" type="text" id="cep" value="" size="10" maxlength="9" onblur="pesquisacep(this.value);"  class="form-control" aria-label="First name" required>
                  
                </div>
               
                <div class="mb-3">
                    <label for = "rua" class="form-label">Rua:</label>
                    <input name="rua" type="text" id="rua" size="60"  class="form-control" aria-label="First name" required>
                   
                </div>
                
                <div class="mb-3">
                    <label for="numero" class="form-label">Número:</label>
                    <input type="text" name="numero" id="numero" class="form-control" aria-label="First name" required>
                    
                    </div>
                    
                <div class="mb-3">
                    <label for = "bairro" class="form-label" >Bairro:</label>
                    <input name="bairro" type="text" id="bairro" size="40" class="form-control" aria-label="First name" required>
                    
                </div> 
                
                <div class="mb-3">
                    <label for = "cidade1"  class="form-label" >Cidade:</label>
                    <input name="cidade1" type="text" id="cidade1" size="40" class="form-control" aria-label="First name"required>
                    
                </div>
                
                <div class="mb-3">
                    <label for = "uf" class="form-label" >Estado:</label>
                    <input name="uf" type="text" id="uf" size="2" class="form-control" aria-label="First name" required>
                    
                </div>
                
                <div class="mb-3">
                    <label for = "name_card" class="form-label">Nome do titular do cartão:</label>
                    <input name="name_card" type="text" id="name_card" class="form-control" aria-label="First name"required>
                    
                </div>
               
                <div class="mb-3">
                    <label for = "num_cartao" class="form-label">Numero do cartão:</label>
                    <input name="num_cartao" type="text" id="num_cartao" class="form-control" aria-label="First name" required>
                   
                </div>
                <div class="input-group mb-3">
              <label class="input-group-text">  Mês:</label>
            <select for="mes_cartao" id="mes_cartao" name="mes_cartao" class="form-select">
                    <option></option>
                    <option value="01">1</option>
                    <option value="02">2</option>
                    <option value="03">3</option>
                    <option value="04">4</option>
                    <option value="05">5</option>
                    <option value="06">6</option>
                    <option value="07">7</option>
                    <option value="08">8</option>
                    <option value="09">9</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>
                    
                  </select>
                  </div>
                  <div class="input-group mb-3">
                <label class="input-group-text">  Ano:</label>
            <select for="ano_cartao" id="ano_cartao" name="ano_cartao" class="form-select">
                    <option></option>
                    <option value="2023">2023</option>
                    <option value="2024">2024</option>
                    <option value="2025">2025</option>
                    <option value="2026">2026</option>
                    <option value="2027">2027</option>
                    <option value="2028">2028</option>
                    <option value="2029">2029</option>
                  </select>
                 </div>
                 <div class="mb-3">
                    <label for = "cvv_cartao" class="form-label" >CVV:</label>
                    <input name="cvv_cartao" type="text" id="cvv_cartao" class="form-control" aria-label="First name" required>
                    
                </div>
                
                <div class="mb-3">
                    <label for = "value" class="form-label">Valor Total:</label>
                    <input name="value" type="text" id="value" class="form-control" aria-label="First name" required>
                   
                </div>
               
            <input type="submit" name="cadastrar_agendamento" id="cadastrar_agendamento" value="FINALIZAR PEDIDO" class="btn btn-primary"/>
            <br><br>
            <button class="btn btn-primary" style="background-color:rgb(199, 199, 243);"> <a href="../../index.php" style="text-decoration: none;"   >VOLTAR</a></button>
            </form>
            <?php endforeach?>
            </fieldset>
            </div>
            <br><br><br>
          </main>
            <footer>
                <div class="card  bg-primary  " >
                 
                  <div class="card-body">
                    <blockquote class="blockquote mb-0">
                      <div class="position-relative">
                      <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
                        <div class="position-absolute top-50 start-0 translate-middle-y">
                        <li class="nav-item ">
                          <a class="nav-link" href="sobre.html">Saiba Mais</a>
                        </li>
                     </div>
                     <div class="position-absolute top-50 start-50 translate-middle">
                      
                        <li class="nav-item ">
                          <a class="nav-link" href="contato.html">Contato</a>
                        </li>
                        </div>
                        <div class="position-absolute top-50 end-0 translate-middle-y">
                        
                        <li class="nav-item">
                          <a class="nav-link" href="https://instagram.com/eletro_tech_solutions?igshid=ZDdkNTZiNTM=" target="_blank">Siga nossas redes</a>
                        </li>
                        </div>
                        
                      </ul>
                      </div>
                      
                    </blockquote>
                  </div>
                </div>
              </footer>
              
    
</body>
</html>