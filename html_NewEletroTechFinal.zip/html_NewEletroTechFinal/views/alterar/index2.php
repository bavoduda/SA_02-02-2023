
<?php

require_once('../../config/Conexao.php');
require_once('../../model/Usuario.php');
require_once('../../dao/UserDao.php');

$usuario = new Usuario();
$userdao = new UserDao();

$login = new UserDao();


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Atualizar dados do Usuário</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
</head>
<body> 

    <h2> Atualizar Dados do Usuário </h2>
    <fieldset style="width:600px; border: 4px solid #098;">
        <legend style="font-size:14pt; font-weight:bolder;"> Atualize seus dados: </legend>
        <form action="../../controller/UsuarioController.php" method="post" name="cad">
            <?php foreach($userdao->editar() as $usuario):?>
            <label> Nome: </label>
            <input type="hidden" name="id_alter" id="id_alter" value="<?=$usuario->getID()?>" required/>
            <input type="text" name="nome" id="nome" value="<?=$usuario->getNome()?>" required/>
            <br/> <br/>
            <label> E-mail: </label>
            <input type="email" name="mail" id="mail" value="<?=$usuario->getEmail()?>" required/>
            <br/> <br/> 
            <label> CPF: </label>
            <input type="text" name="cpf" id="cpf" value="<?=$usuario->getCPF()?>" required/>
            <br/> <br/>
            <label> Telefone: </label>
            <input type="tel" name="telefone" id="telefone" value="<?=$usuario->getTelefone()?>" required/>
            <br/> <br/>  
            <label> Sexo: </label>
            <select id="sexo" name="sexo">
                <option value="" selected>--Selecione--</option>
                <option value="M"<?= $usuario->getSexo() == "M" ? "selected" : ""?>> Masculino </option>
                <option value="F" <?= $usuario->getSexo() == "F" ? "selected" : ""?>> Feminino </option>
                <option value="O" <?= $usuario->getSexo() == "O" ? "selected" : ""?>> Outro </option>
            </select>
            <br><br>
                    <label for="data_nascimento"><b>Data de Nascimento:</b></label>
                    <input type="date" name="data_nascimento" id="data_nascimento" value = "<?=$usuario->getData_nascimento()?>" required>
            <br/> <br/>
            <label> Senha: </label>
            <input type="password" name="senha" id="senha" required/>
            <br/> <br/>
            <input type="submit" name="alterar" id="alterar" value="ALTERAR"/>
            <button> <a href="../../index.php" style="text-decoration: none;">VOLTAR</a></button>

            <?php endforeach?>
        </form>
       </fieldset> 
    
</body>
</html>