<?php

echo '<!DOCTYPE html>
<html lang="pt-br">
<head>
  <title>Página Principal</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body >

  <style>
   
   body{
    background-color: rgb(200, 221, 248);
   } 
   nav{
    font-weight: bolder;
   
   } 

   .hide{
    display: none;
   }

   footer{
    font-weight: bolder;
   } 

   .a{
    background-color: #0d6efd;;
    border: 0ch;
    font-weight: bold; 
   font-size: 12pt;
   
   } 
   
   
  </style> 

    <nav  class="navbar  bg-primary navbar-expand-lg  bg-body-tertiary fixed-top"  style="z-index: 999; " data-bs-theme="dark" >
        <div class="container-fluid">
         
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0" >
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="../../views/users/index2.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="./views/sobre/sobre.html">Sobre</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="./views/contato/contato.html">Contato</a>
              </li>
              <li class="nav-item">
              <form action="views/agendamento/index.php" method="post" name="agendamento" class="a" >
                            <input type="hidden" id="id_edit" name="id_edit" value="' . $usuario->getID() . '"/>
                            <button type="submit" class="a"> <a class="nav-link">Agendamento</a> </button>
                        </form>
              </li>
              <li>
              <form action="views/alterar/index.php" method="post" name="edit">
                  <input type="hidden" id="id_edit" name="id_edit" value="' . $usuario->getID() . '"/>
                  <button type="submit" class="a"> <a class="nav-link">Alterar Cadastro</a> </button>
                  </form>
            </li>
            <div class="position-absolute top-0 end-0">
            <button type="submit" class="a"> <a href="./controller/UsuarioController.php?logout=true"  class="nav-link"> Sair </a> </button> <li> </li>
            </div>
              <script src="script.js"></script>
            </ul>
            <div class="position-absolute top-50 start-50 translate-middle">
            <form class="d-flex " role="search">
              <div class="input-group mb-3">
                <input type="search" id="busca" class="form-control" placeholder="Pesquisar" list="menu" autocomplete="off" onkeyup="Pesquisar()">
                <datalist id="menu">
                  <option>Contato</option>
                  <option>Cadastro</option>
                  <option>Sobre</option>
                  <option> Siga nossas redes</option>
                  <option>  Login </option>
                </datalist>
                <div class="input-group-append">
                  <button class="btn btn-success" type="submit">Search</button>
                </div>
                </div>
                
            </form>
            </div>
           <br><br>
           
            <div class="position-absolute bottom-0 end-0">
            
             <a href="index.php"  ><img src="./img/perfil.png" alt="some text" width=35 height=30></a>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </nav>
      <main>
        
        <div class="container text-center">
            <div class="col align-self-center">
      <h4 class="position-absolute top-50 start-50 translate-middle m-auto"> Bem vindo(a), ' . $usuario->getNome() . '. </h4>
      </div>
      </div>
     <br><br><br> 
       <br>
       
      
        <img class="rounded mx-auto d-block"src="./img/Logo-azul.png" alt="Logo" width=550 height=120>
        
      <br><br><br><br>  <br><br><br>
      
      <div id="carouselExampleCaptions" class="carousel slide col-9 m-auto" >
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="./img/imagem1.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
             
            </div>
          </div>
          <div class="carousel-item">
            <img src="./img/imagem2.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
             
            </div>
          </div>
          <div class="carousel-item">
            <img src="./img/imagem3.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
             
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
      <br>
      
        
      <div class="row row-cols-1 row-cols-md-3 g-4 col-10 m-auto">
        <div class="col">
          <div class="card h-100">
            <img src="./img/imagem4.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Instalação de Padrão de Energia Elétrica</h5>
              <p class="card-text" align="justify">O padrão de ligação de energia elétrica é composto por poste, caixa de medidor, eletrodutos, fios, haste de aterramento e disjuntor de proteção.</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100">
            <img src="./img/imagem5.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Reparo em Rede Elétrica Residencial</h5>
              <p class="card-text" align="justify">As manutenções são essenciais para garantir um bom funcionamento das instalações elétricas, evitando paradas inesperadas em sua operação.</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card h-100">
            <img src="./img/imagem6.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Instalação de Tomadas e Interruptores</h5>
              <p class="card-text" align="justify">O interruptor é um componente elétrico que possibilita comandar um ponto de iluminação. Já a tomada é um ponto que fornece energia elétrica para um plugue que será conectado na tomada.</p>
            </div>
          </div>
        </div>
        
          </div>
          <br><br><br>
          <div class="card border-dark mb-3 m-auto" style="max-width: 25rem;">
            
            <div class="card-body">
              
              <p class="card-text">"O sucesso de um empresa é o resultado do trabalho de uma grande equipe"</p>
              <div class="card-header">Edi Carlos Junior</div>
            </div>
          </div>
      
     
      <br><br><br><br><br>
      
      </main>
      <footer>
        <div class="card  bg-primary  " >
         
          <div class="card-body">
            <blockquote class="blockquote mb-0">
              <div class="position-relative">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
                <div class="position-absolute top-50 start-0 translate-middle-y">
                <li class="nav-item ">
                  <a class="nav-link" href="./views/sobre/sobre.html">Saiba Mais</a>
                </li>
             </div>
             <div class="position-absolute top-50 start-50 translate-middle">
              
                <li class="nav-item ">
                  <a class="nav-link" href="../../views/contato/contato.html">Contato</a>
                </li>
                </div>
                <div class="position-absolute top-50 end-0 translate-middle-y">
                
                <li class="nav-item">
                  <a class="nav-link" href="https://instagram.com/eletro_tech_solutions?igshid=ZDdkNTZiNTM=" target="_blank">Siga nossas redes</a>
                </li>
                </div>
                
              </ul>
              </div>
              
            </blockquote>
          </div>
        </div>
      </footer>
      
</body>
</html>';

?>
