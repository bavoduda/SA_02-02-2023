<?php 

echo '<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title> Tela - Adiministrador </title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    </head>
    <body>
        <style>

            body{
             background-color: rgb(200, 221, 248);
            } 
            nav{
             font-weight: bolder;
             
            
            } 
    
          hr{
            background-color: rgb(4, 4, 99);
            size: 10px;
          }
    
         
            footer{
             font-weight: bolder;
            }
           </style> 
        <nav class="navbar  bg-primary navbar-expand-lg  bg-body-tertiary fixed-top"  style="z-index: 999; " data-bs-theme="dark" >
            <div class="container-fluid">
             
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" >
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../../views/users/admin.php">Home</a>
                      </li>
                    <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="views/cadastro">Cadastrar Usuários</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="views/produto"> Cadastrar Produtos</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="views/listar">Listar Usuários</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link"  href="views/produto/listar.php">Listar Produtos</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="./controller/UsuarioController.php?logout=true">Sair</a>
                  </li>
                  
                </ul>
               
                <script src="script.js"></script>
                <div class="position-absolute top-50 end-0 translate-middle-y ">
                 <a href="#"><img src= "./img/perfil.png" alt="Perfil" width=60 height=40></a>
                    </div>
                    
                  </div>
                </div>
              
          
          </nav>
          <br><br><br>
         
           
          <main>
            <br><br>
            <h2 align="center">  Administrador </h2>
            <img class="rounded mx-auto d-block" src= "./img/Logo-azul.png" alt="Logo" width=550 height=150>
           <br><br>
            <h4 align="center"> Bem vindo(a), ' . $usuario->getNome() . '. </h4>
          
          <br><br><br>
          <br><br><br>

          
          <div class="card border-dark mb-3 m-auto" style="max-width: 25rem;">
            
            <div class="card-body">
              
              <p class="card-text">"O sucesso de um empresa é o resultado do trabalho de uma grande equipe"</p>
              <div class="card-header">Edi Carlos Junior</div>
            </div>
          </div>
      <br><br><br>
      <br><br><br>
      <br><br><br>
      
  
  
          </main>
      
        
          <footer>
            <div class="card  bg-primary  " >
             
              <div class="card-body">
                <blockquote class="blockquote mb-0">
                  <div class="position-relative">
                  <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
                    <div class="position-absolute top-50 start-0 translate-middle-y">
                    <li class="nav-item ">
                      <a class="nav-link" href="./views/sobre/sobre.html">Saiba Mais</a>
                    </li>
                 </div>
                 <div class="position-absolute top-50 start-50 translate-middle">
                  
                    <li class="nav-item ">
                      <a class="nav-link" href="./views/contato/contato.html">Contato</a>
                    </li>
                    </div>
                    <div class="position-absolute top-50 end-0 translate-middle-y">
                    
                    <li class="nav-item">
                      <a class="nav-link" href="https://instagram.com/eletro_tech_solutions?igshid=ZDdkNTZiNTM=" target="_blank">Siga nossas redes</a>
                    </li>
                    </div>
                    
                  </ul>
                  </div>
                  
                </blockquote>
              </div>
            </div>
          </footer>
    </body>
</html>';


?>