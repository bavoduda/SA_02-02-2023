<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Login </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

   
   
</head>
<body> 
    <style>
   
        body{
         background-color: rgb(200, 221, 248);
        } 
        nav{
         font-weight: bolder;
         
        
        } 

      hr{
        background-color: rgb(4, 4, 99);
        size: 10px;
      }

     
        footer{
         font-weight: bolder;
        }
       </style> 
       <main>
       <br><br><br>
    <img class="rounded mx-auto d-block m-auto "  src="../../img/Logo-azul.png" alt="some text" width=350 height=100>

        <br><br>
    <div class="container-lg" >
    <h2 align="center"> Entrar </h2>
   
        <form action="../../controller/UsuarioController.php" method="post" name="cad" class="row g-3 m-auto">
            <div class="mb-3" >
            
            <input type="email" name="mail" id="mail"  class="form-control" placeholder="Email" required/>
            </div>
            
            <div class="mb-3" >
            <input type="password" name="senha" id="senha"  class="form-control" placeholder="Senha" required/>
            <img id="mostrarsenha" onclick="mostrar()" width="25px" src="../../img/open.png" alt="senha">
            <script src="senha.js">  </script>
            </div>
            <div class="mb-3" >
            <input type="submit" class="btn btn-primary" name="login" id="login" value="ENTRAR"/>
            </div>
            <div class="mb-3" >
            <button class="btn btn-primary"  style="background-color:rgb(199, 199, 243);"> <a href="../cadastro/" style="text-decoration: none;">CADASTRAR</a></button>
        </div>
        </form>
      

    </div>
    </main>
    
</body>
</html>