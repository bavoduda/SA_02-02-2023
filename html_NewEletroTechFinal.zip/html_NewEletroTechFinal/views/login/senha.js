const passwordInput = document.getElementById("senha")
const mostrarsenha= document.getElementById("mostrarsenha")


function mostrar(){
    let inputTypeIsPassword = passwordInput.type == "password"

    if (inputTypeIsPassword){
     showPassword()
    }else{
    hidePassword()
    }
} 

function showPassword(){
    passwordInput.setAttribute("type", "text")
    mostrarsenha.setAttribute("src","../../img/closed.png")
} 

function hidePassword(){
    passwordInput.setAttribute("type","password")
    mostrarsenha.setAttribute("src","../../img/open.png")
}