<?php

session_start();

require_once('../../config/Conexao.php');
require_once('../../model/Usuario.php');
require_once('../../dao/UserDao.php');

$login = new UserDao();

if($login->checkLogin()) {
    header("location: ../../");
}

?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Login </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
            background-image: linear-gradient(to right, rgb(20,147,220), rgb(17, 54, 71));
        }

        .box{
            color: white;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: rgba(0, 0, 0, 0.6);
            padding: 15px;
            border-radius: 15px;
        }
        fieldset{
            border: 3px solid dodgerblue;
        }
        legend{
            border: 1px solid dodgerblue;
            padding: 10px;
            text-align: center;
            background-color: dodgerblue;
            border-radius: 8px;
        }
        .inputBox{
            position: relative;
        }
        .inputUser{
            background: none;
            border: none;
            border-bottom: 1px solid white;
            outline: none;
            color: white;
            font-size: 15px;
            width: 100%;
            letter-spacing: 2px;
        }
        .labelinput{
            position: absolute;
            top: 0px;
            left: 0px;
            pointer-events: none;
            transition: .5s;
        }
        .labelinputcpf{
            position: absolute;
            top: 0px;
            left: 0px;
            pointer-events: none;
            transition: .5s;
        }
        .inputUser:focus ~ .labelinput, .inputUser:valid ~ .labelinput{
            top: -20px;
            font-size: 12px;
            color: dodgerblue;
        } 
        
        #data_nascimento{
            border: none;
            padding: 8px;
            border-radius: 10px;
            outline: none;
            font-size: 15px;
        }
        #login, button{
            background-image: linear-gradient(to right, rgb(0, 92, 197), rgb(90, 20, 220));
            width: 100%;
            border: none;
            padding: 15px;
            color: white;
            font-size: 15px;
            cursor: pointer;
            border-radius: 10px;
        }

        .btn_cadastro{
            background-image: linear-gradient(to right, rgb(0, 92, 197), rgb(90, 20, 220));
            color: white;
            font-size: 15px;
            padding: 15px 210px;
            text-decoration: none;
            cursor: pointer;
            border-radius: 10px;
        }

    .btn_voltar{

            background-image: linear-gradient(to right, rgb(0, 92, 197), rgb(90, 20, 220));
            color: white;
            font-size: 15px;
            padding: 15px 227px;
            text-decoration: none;
            cursor: pointer;
            border-radius: 10px;
    }

        #login, .btn:hover{
            background-image: linear-gradient(to right, rgb(0, 80, 172), rgb(80, 19, 195));
        }
    </style>
   
</head>
<body> 

<div class="box">
    <h2> Acessar Sistema </h2>
    <fieldset style="width:400px; border: 4px solid #098;">
        <legend style="font-size:14pt; font-weight:bolder;"> Insira seus dados: </legend>
        <form action="../../controller/UsuarioController.php" method="post" name="cad">

            <label> E-mail: </label>
            <input type="email" name="mail" id="mail" class="inputUser" required/>
            <br/> <br/>
            <label> Senha: </label>
            <input type="password" name="senha" id="senha" class="inputUser" required/>
            <br/> <br/>
            <input type="submit" name="login" id="login" value="ENTRAR"/>
            <br/> <br/>
            <a class="btn_cadastro" href="../cadastro/">CADASTRAR</a>
            <br/> <br/> <br/>
            <a class="btn_voltar" href="../../main.php">VOLTAR</a> 
            <br/> <br/>
        </form>
       </fieldset> 

    </div>
    
</body>
</html>

