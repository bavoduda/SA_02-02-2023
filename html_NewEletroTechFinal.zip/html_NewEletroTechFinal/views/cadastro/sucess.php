<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cadastrar Usuário </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
            background-image: linear-gradient(to right, rgb(20,147,220), rgb(17, 54, 71));
        }

        .box{
            color: white;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: rgba(0, 0, 0, 0.6);
            padding: 15px;
            border-radius: 15px;
        }
        fieldset{
            border: 3px solid dodgerblue;
        }
        
        .inputBox{
            position: relative;
        }
        
        .inputUser:focus ~ .labelinput, .inputUser:valid ~ .labelinput{
            top: -20px;
            font-size: 12px;
            color: dodgerblue;
        } 

        .btn_voltar{
            background-image: linear-gradient(to right, rgb(0, 92, 197), rgb(90, 20, 220));
            color: white;
            font-size: 15px;
            padding: 15px 210px;
            text-decoration: none;
            cursor: pointer;
            border-radius: 10px;
        }

        .btn_voltar:hover{
            background-image: linear-gradient(to right, rgb(0, 80, 172), rgb(80, 19, 195));
        }
    </style>
   
</head>
<body> 

    <div class="box">
    <h2> USUARIO CADASTRADO COM SUCESSO </h2>
            <br/> <br/>
            <a class="btn_voltar" href="../../index.php">VOLTAR</a> 
       </fieldset> 
    </form>
    </div>
</body>
</html>