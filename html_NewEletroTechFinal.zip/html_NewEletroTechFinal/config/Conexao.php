<?php

class Conexao {
    
    // Variavél que guarda as Informações de Conexão com o Banco de Dados (pdo)
    protected static $conexao;
    
    //Classe de conexao Privada - Só pode ser instanciada internamente.
    private function __construct(){ 

        #informações e configurações para conexao com BD.
        $db_host = "localhost";
        $db_nome ="mvc_php_dao";
        $db_usuario = "root";
        $db_senha = "";
        $db_driver = "mysql";

        try  {
            // Atribui o objeto PDO à variável $conexao.
            self::$conexao = new PDO("$db_driver:host=$db_host; dbname=$db_nome", $db_usuario, $db_senha);
            // Garante que o PDO lance exceções durante erros.
            self::$conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // Garante que os dados sejam armazenados com codificação UFT-8.
            self::$conexao->exec('SET NAMES utf8');

            // echo "Conectado com sucesso!!";
        }
        catch (PDOException $e)
        {
            // Mensagem de erro com Banco de dados.
            echo "Erro na conexão com Banco de Dados: " . $e->getMessage();
        }
    }

    // Método estático - acessível sem instanciação.
    public static function getConexao() {
        // Garante uma única instância. Se não existe uma conexão, criamos uma nova.
        if (!self::$conexao) {
            new Conexao();
        }

        // Retorna a conexão.
        return self::$conexao;
    }

}

?>