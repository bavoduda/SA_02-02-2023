<?php

require_once('../config/Conexao.php');
require_once('../model/Usuario.php');
require_once('../dao/UserDao.php');

$usuario = new Usuario();
$userdao = new UserDao();

$dados = filter_input_array(INPUT_POST);

//echo var_dump($usuario);
//echo var_dump($dados); 

//Se a condição do submit do formulário for cadastrar, entra no formulário para gravar os dados
if (isset($_POST['cadastrar'])) {
   $usuario->setNome($dados['nome']);
   $usuario->setEmail($dados['mail']);
   $usuario->setCPF($dados['cpf']);
   $usuario->setTelefone($dados['telefone']);
   $usuario->setSexo($dados['sexo']);
   $usuario->setData_nascimento($dados['data_nascimento']);
   $usuario->setSenha(password_hash($dados['senha'], PASSWORD_DEFAULT)); 

   if($userdao->criar($usuario)) { 
      echo "<script> 
         location.href = '../views/cadastro/sucess.php';
         </script>"; 
   }

}else if (isset($_POST['alterar'])) {
      $usuario->setID($dados['id_alter']);
      $usuario->setNome($dados['nome']);
      $usuario->setEmail($dados['mail']);
      $usuario->setCPF($dados['cpf']);
      $usuario->setTelefone($dados['telefone']);
      $usuario->setSexo($dados['sexo']);
      $usuario->setSenha(password_hash($dados['senha'], PASSWORD_DEFAULT)); 
   
      if($userdao->alterar($usuario)) {
      echo "<script> 
       alert('Usuário Atualizado com Sucesso!!') 
       location.href = '../views/listar/index.php';
      </script>";
      }

//Caso a condição seja excluir, ele irá deletar dados do usuario de um ID específico.
}elseif(isset($_POST['excluir'])) { 

   $usuario->setID($_POST['id_del']);

   if($userdao->excluir($usuario)) { 
   echo "<script> 
            alert('Usuário Excluido com Sucesso!!') 
            location.href = '../views/listar/index.php';
         </script>";
   }

   }elseif(isset($_POST['login'])) { 

      $usuario->setEmail(strip_tags($dados['mail']));
      $usuario->setSenha(strip_tags($dados['senha']));
      
      $userdao->login($usuario);

      if($userdao->login($usuario)) {

         echo "<script>  
         location.href = '../';
         </script>"; 

      } else {

         echo "<script> 
         alert('Acesso Negado! Login ou Senha Incorretos!!') 
         location.href = '../views/login';
         </script>"; 

      }


} elseif(isset($_GET['logout'])) { 

   $userdao->logout();
   header("Location: ../main.php");

}   else {
   header("Location: ../");
}


?>