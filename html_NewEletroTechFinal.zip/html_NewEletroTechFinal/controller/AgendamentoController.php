<?php

require_once('../config/Conexao.php');
require_once('../dao/UserDao.php');
require_once('../dao/AgendamentoDao.php');
require_once('../model/Usuario.php');
require_once('../model/Agendamento.php');

   $agendamento = new Agendamento();
   $agendamentodao = new AgendamentoDao();
   $usuario = new Usuario();
   $userdao = new UserDao();

$dados = filter_input_array(INPUT_POST);

//echo var_dump($usuario);
//echo var_dump($dados); 

//Se a condição do submit do formulário for cadastrar, entra no formulário para gravar os dados
if (isset($_POST['cadastrar_agendamento'])) {  

   $agendamento->setID_usuario($dados['id_user']);
   $agendamento->setTipo_agendamento($dados['tipo_agendamento']);
   $agendamento->setData_agendamento($dados['data_agendamento']);
   $agendamento->setNome($dados['nome']);
   $agendamento->setEmail($dados['mail']);
   $agendamento->setCPF($dados['cpf']);
   $agendamento->setTelefone($dados['telefone']);
   $agendamento->setSexo($dados['sexo']);
   $agendamento->setCep($dados['cep']);
   $agendamento->setRua($dados['rua']);
   $agendamento->setNumero($dados['numero']);
   $agendamento->setBairro($dados['bairro']);
   $agendamento->setCidade($dados['cidade1']);
   $agendamento->setEstado($dados['uf']);


   echo var_dump($dados);

   if($agendamentodao->criar($agendamento)) { 
      echo "<script> 
         alert('Agendamento Cadastrado com Sucesso!!') 
         location.href = '../';
         </script>"; 
   }

}else if (isset($_POST['alterar'])) {
      $usuario->setID($dados['id_alter']);
      $usuario->setNome($dados['nome']);
      $usuario->setEmail($dados['mail']);
      $usuario->setCPF($dados['cpf']);
      $usuario->setTelefone($dados['telefone']);
      $usuario->setSexo($dados['sexo']);
      $usuario->setSenha(password_hash($dados['senha'], PASSWORD_DEFAULT)); 
   
      if($userdao->alterar($usuario)) {
      echo "<script> 
       alert('Usuário Atualizado com Sucesso!!') 
       location.href = '../views/listar/index.php';
      </script>";
      }

//Caso a condição seja excluir, ele irá deletar dados do usuario de um ID específico.
}elseif(isset($_POST['excluir'])) { 

   $usuario->setID($_POST['id_del']);

   if($userdao->excluir($usuario)) { 
   echo "<script> 
            alert('Usuário Excluido com Sucesso!!') 
            location.href = '../';
         </script>";
   }

   }elseif(isset($_POST['login'])) { 

      $usuario->setEmail(strip_tags($dados['mail']));
      $usuario->setSenha(strip_tags($dados['senha']));
      
      $userdao->login($usuario);

      if($userdao->login($usuario)) {

         echo "<script>  
         location.href = '../';
         </script>"; 

      } else {

         echo "<script> 
         alert('Acesso Negado! Login ou Senha Incorretos!!') 
         location.href = '../views/login';
         </script>"; 

      }


} elseif(isset($_GET['logout'])) { 

   $userdao->logout();
   header("Location: ../views/login/");

}   else {
   header("Location: ../");
}


?>